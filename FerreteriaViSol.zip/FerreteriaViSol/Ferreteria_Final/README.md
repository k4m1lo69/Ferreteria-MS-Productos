# Ferretería Online — Arquitectura de Microservicios

Sistema backend REST para ferretería, construido con Spring Boot 3.4.5, JWT y PostgreSQL.

## Microservicios

| Microservicio   | Puerto | Base de Datos   | Descripción                    |
|-----------------|--------|-----------------|-------------------------------|
| ms-auth         | 8080   | db_auth         | Autenticación y registro JWT  |
| ms-productos    | 8081   | db_productos    | Catálogo de productos         |
| ms-clientes     | 8082   | db_clientes     | Gestión de usuarios/clientes  |
| ms-inventario   | 8083   | db_inventario   | Control de stock              |
| ms-pedidos      | 8084   | db_pedidos      | Gestión de órdenes            |
| ms-pagos        | 8085   | db_pagos        | Procesamiento de pagos        |
| ms-reportes     | 8086   | db_reportes     | Reportes y consultas          |

## Seguridad JWT

Todos los servicios (excepto ms-auth) requieren el header:
```
Authorization: Bearer <token>
```
El token se obtiene haciendo POST a `http://localhost:8080/api/auth/login`.

La llave secreta JWT es **compartida** entre todos los microservicios y se configura en cada `application.properties`:
```properties
jwt.secret=ferreteria_secret_key_2024_must_be_at_least_256_bits_long_secure
```

## Requisitos previos

- Java 21
- Maven 3.9+
- PostgreSQL (Laragon recomendado en Windows)

## Bases de datos (crear antes de iniciar)

Conectarse a PostgreSQL (puerto 5432) y ejecutar:
```sql
CREATE DATABASE db_auth;
CREATE DATABASE db_productos;
CREATE DATABASE db_clientes;
CREATE DATABASE db_inventario;
CREATE DATABASE db_pedidos;
CREATE DATABASE db_pagos;
CREATE DATABASE db_reportes;
```

## Comandos Maven

### Compilar un microservicio
```bash
cd ms-auth
mvn clean compile
```

### Ejecutar tests
```bash
mvn test
```

### Generar el JAR ejecutable
```bash
mvn clean package
```

### Ejecutar el JAR generado
```bash
java -jar target/ms-auth-0.0.1-SNAPSHOT.jar
```

### Compilar y ejecutar directamente
```bash
mvn spring-boot:run
```

### Saltar tests al compilar
```bash
mvn clean package -DskipTests
```

### Compilar todos los microservicios (desde la raíz del proyecto)
```bash
for ms in ms-auth ms-productos ms-clientes ms-inventario ms-pedidos ms-pagos ms-reportes; do
  echo "=== Building $ms ==="
  cd $ms && mvn clean package -DskipTests && cd ..
done
```

## Flujo de uso con Postman / curl

### 1. Registrar usuario
```bash
POST http://localhost:8080/api/auth/register
Content-Type: application/json

{
  "username": "admin",
  "password": "admin123",
  "rol": "ADMIN"
}
```

### 2. Login → obtener token
```bash
POST http://localhost:8080/api/auth/login
Content-Type: application/json

{
  "username": "admin",
  "password": "admin123"
}
```
Respuesta:
```json
{
  "token": "eyJhbGciOiJIUzI1NiJ9...",
  "username": "admin",
  "rol": "ADMIN"
}
```

### 3. Usar el token en los demás servicios
```bash
GET http://localhost:8081/api/productos
Authorization: Bearer eyJhbGciOiJIUzI1NiJ9...
```

## Endpoints principales

### ms-auth (puerto 8080) — público
| Método | Endpoint               | Descripción        |
|--------|------------------------|--------------------|
| POST   | /api/auth/register     | Registrar usuario  |
| POST   | /api/auth/login        | Login → JWT token  |
| GET    | /api/auth/usuarios     | Listar usuarios    |

### ms-productos (puerto 8081) — requiere JWT
| Método | Endpoint              | Descripción          |
|--------|-----------------------|----------------------|
| POST   | /api/productos        | Crear producto       |
| GET    | /api/productos        | Listar productos     |
| GET    | /api/productos/{id}   | Obtener por ID       |
| PUT    | /api/productos/{id}   | Actualizar producto  |
| DELETE | /api/productos/{id}   | Eliminar producto    |

### ms-clientes (puerto 8082) — requiere JWT
| Método | Endpoint             | Descripción         |
|--------|----------------------|---------------------|
| POST   | /api/clientes        | Crear cliente       |
| GET    | /api/clientes        | Listar clientes     |
| GET    | /api/clientes/{id}   | Obtener por ID      |
| PUT    | /api/clientes/{id}   | Actualizar cliente  |
| DELETE | /api/clientes/{id}   | Eliminar cliente    |

### ms-inventario (puerto 8083) — requiere JWT
| Método | Endpoint               | Descripción           |
|--------|------------------------|-----------------------|
| POST   | /api/inventario        | Registrar stock       |
| GET    | /api/inventario        | Listar inventario     |
| GET    | /api/inventario/{id}   | Obtener por ID        |
| PUT    | /api/inventario/{id}   | Actualizar stock      |

### ms-pedidos (puerto 8084) — requiere JWT
| Método | Endpoint                          | Descripción           |
|--------|-----------------------------------|-----------------------|
| POST   | /api/pedidos                      | Crear pedido          |
| GET    | /api/pedidos                      | Listar pedidos        |
| GET    | /api/pedidos/{id}                 | Obtener por ID        |
| GET    | /api/pedidos/cliente/{clienteId}  | Pedidos por cliente   |
| PUT    | /api/pedidos/{id}/estado          | Actualizar estado     |

### ms-pagos (puerto 8085) — requiere JWT
| Método | Endpoint                        | Descripción           |
|--------|---------------------------------|-----------------------|
| POST   | /api/pagos                      | Registrar pago        |
| GET    | /api/pagos                      | Listar pagos          |
| GET    | /api/pagos/{id}                 | Obtener por ID        |
| GET    | /api/pagos/pedido/{pedidoId}    | Pagos por pedido      |
| PUT    | /api/pagos/{id}/estado          | Actualizar estado     |

### ms-reportes (puerto 8086) — requiere JWT
| Método | Endpoint                    | Descripción           |
|--------|-----------------------------|-----------------------|
| POST   | /api/reportes               | Generar reporte       |
| GET    | /api/reportes               | Listar reportes       |
| GET    | /api/reportes/{id}          | Obtener por ID        |
| GET    | /api/reportes/tipo/{tipo}   | Filtrar por tipo      |

## Repositorios Git

Cada microservicio tiene su propio repositorio (1 repo por microservicio):

```
github.com/usuario/ms-auth
github.com/usuario/ms-productos
github.com/usuario/ms-clientes
github.com/usuario/ms-inventario
github.com/usuario/ms-pedidos
github.com/usuario/ms-pagos
github.com/usuario/ms-reportes
```

Pasos para inicializar cada repositorio:
```bash
cd ms-auth
git init
git add .
git commit -m "feat: initial project structure"
# ... desarrollar más ...
git commit -m "feat: add JWT authentication"
git remote add origin https://github.com/usuario/ms-auth.git
git push -u origin main
```

> **Importante**: el profesor requiere más de un commit en días diferentes.
> Hacer al menos 2 commits en días distintos por repositorio.

## Tecnologías

- Java 21
- Spring Boot 3.4.5
- Spring Security + JWT (jjwt 0.12.6)
- Spring Data JPA + Hibernate 6
- PostgreSQL 14+
- Lombok
- Maven 3.9
