package com.ferreteria.ms_reportes.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.*;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class ReporteDTO {
    private Long id;

    @NotBlank(message = "tipo obligatorio")
    private String tipo;

    @NotBlank(message = "descripcion obligatoria")
    private String descripcion;

    private String fechaGeneracion;
    private String estado;
}
