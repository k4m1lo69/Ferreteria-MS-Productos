package com.ferreteria.ms_reportes.service;

import com.ferreteria.ms_reportes.dto.ReporteDTO;
import com.ferreteria.ms_reportes.model.Reporte;
import com.ferreteria.ms_reportes.repository.ReporteRepository;
import org.springframework.stereotype.Service;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class ReporteService {
    private final ReporteRepository reporteRepository;
    public ReporteService(ReporteRepository reporteRepository) {
        this.reporteRepository = reporteRepository;
    }

    public ReporteDTO save(ReporteDTO dto) {
        Reporte r = Reporte.builder()
                .tipo(dto.getTipo())
                .descripcion(dto.getDescripcion())
                .fechaGeneracion(LocalDateTime.now())
                .estado("GENERADO")
                .build();
        return toDTO(reporteRepository.save(r));
    }

    public List<ReporteDTO> getAll() {
        return reporteRepository.findAll().stream()
                .map(this::toDTO).collect(Collectors.toList());
    }

    public ReporteDTO getById(Long id) {
        return toDTO(reporteRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Reporte no encontrado")));
    }

    public List<ReporteDTO> getByTipo(String tipo) {
        return reporteRepository.findByTipo(tipo).stream()
                .map(this::toDTO).collect(Collectors.toList());
    }

    private ReporteDTO toDTO(Reporte r) {
        return ReporteDTO.builder()
                .id(r.getId()).tipo(r.getTipo())
                .descripcion(r.getDescripcion())
                .fechaGeneracion(r.getFechaGeneracion().toString())
                .estado(r.getEstado()).build();
    }
}
