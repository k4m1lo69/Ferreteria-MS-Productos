package com.ferreteria.ms_pagos.dto;

import jakarta.validation.constraints.*;
import lombok.*;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class PagoDTO {
    private Long id;

    @NotNull(message = "pedidoId obligatorio")
    private Long pedidoId;

    @NotNull(message = "monto obligatorio")
    @Positive(message = "monto debe ser positivo")
    private Double monto;

    @NotBlank(message = "metodoPago obligatorio")
    private String metodoPago;

    private String estado;
    private String fecha;
}
