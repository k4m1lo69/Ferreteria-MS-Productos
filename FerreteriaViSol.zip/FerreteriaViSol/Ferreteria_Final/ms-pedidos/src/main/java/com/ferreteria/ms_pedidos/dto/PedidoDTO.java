package com.ferreteria.ms_pedidos.dto;

import jakarta.validation.constraints.*;
import lombok.*;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class PedidoDTO {

    private Long id;

    @NotNull(message = "Cliente ID obligatorio")
    private Long clienteId;

    @NotNull(message = "Producto ID obligatorio")
    private Long productoId;

    @NotNull(message = "Cantidad obligatoria")
    @Min(value = 1, message = "Cantidad mínima 1")
    private Integer cantidad;

    @NotNull(message = "Precio obligatorio")
    @Min(value = 0, message = "Precio inválido")
    private Double precioUnitario;

    private Double total;

    private String estado;
}