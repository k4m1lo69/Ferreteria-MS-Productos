package com.ferreteria.ms_inventario.dto;

import jakarta.validation.constraints.*;
import lombok.*;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class InventarioDTO {

    private Long id;

    @NotNull(message = "Producto ID obligatorio")
    private Long productoId;

    @NotNull(message = "Stock obligatorio")
    @Min(value = 0, message = "Stock inválido")
    private Integer stock;

    @NotNull(message = "Stock mínimo obligatorio")
    @Min(value = 0, message = "Stock mínimo inválido")
    private Integer stockMinimo;

    @NotBlank(message = "Ubicación obligatoria")
    private String ubicacion;
}